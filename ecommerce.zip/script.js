// Product data
const products = [
    {
        id: 1,
        name: "Wireless Headphones",
        price: 99.99,
        image: "https://via.placeholder.com/300x300",
        description: "High-quality wireless headphones with noise cancellation"
    },
    {
        id: 2,
        name: "Smart Watch",
        price: 199.99,
        image: "https://via.placeholder.com/300x300",
        description: "Feature-rich smartwatch with health tracking"
    },
    {
        id: 3,
        name: "Laptop Backpack",
        price: 49.99,
        image: "https://via.placeholder.com/300x300",
        description: "Durable laptop backpack with multiple compartments"
    },
    {
        id: 4,
        name: "Bluetooth Speaker",
        price: 79.99,
        image: "https://via.placeholder.com/300x300",
        description: "Portable bluetooth speaker with great sound quality"
    },
    // Add more products as needed
];

// Cart state
let cart = [];

// DOM Elements
const productGrid = document.getElementById('productGrid');
const cartButton = document.getElementById('cartButton');
const cartModal = document.getElementById('cartModal');
const closeCart = document.getElementById('closeCart');
const cartItems = document.getElementById('cartItems');
const cartCount = document.getElementById('cartCount');
const cartTotal = document.getElementById('cartTotal');
const menuButton = document.getElementById('menuButton');
const mobileMenu = document.getElementById('mobileMenu');

// Initialize the page
document.addEventListener('DOMContentLoaded', () => {
    displayProducts();
    setupEventListeners();
});

// Display products
function displayProducts() {
    productGrid.innerHTML = products.map(product => `
        <div class="product-card">
            <img src="${product.image}" alt="${product.name}" class="w-full h-48 object-cover rounded-lg mb-4">
            <h3 class="text-xl font-semibold mb-2">${product.name}</h3>
            <p class="text-gray-600 mb-4">${product.description}</p>
            <div class="flex justify-between items-center">
                <span class="text-xl font-bold">$${product.price}</span>
                <button onclick="addToCart(${product.id})" class="btn-primary">
                    Add to Cart
                </button>
            </div>
        </div>
    `).join('');
}

// Setup Event Listeners
function setupEventListeners() {
    cartButton.addEventListener('click', toggleCart);
    closeCart.addEventListener('click', toggleCart);
    menuButton.addEventListener('click', toggleMobileMenu);

    // Close cart when clicking outside
    window.addEventListener('click', (e) => {
        if (e.target === cartModal) {
            toggleCart();
        }
    });
}

// Toggle mobile menu
function toggleMobileMenu() {
    mobileMenu.classList.toggle('hidden');
}

// Toggle cart modal
function toggleCart() {
    cartModal.classList.toggle('hidden');
    updateCart();
}

// Add item to cart
function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    const existingItem = cart.find(item => item.id === productId);

    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({
            ...product,
            quantity: 1
        });
    }

    updateCartCount();
    showNotification('Item added to cart!');
}

// Update cart display
function updateCart() {
    cartItems.innerHTML = cart.map(item => `
        <div class="cart-item">
            <img src="${item.image}" alt="${item.name}" class="cart-item-img">
            <div class="flex-grow ml ▋